#include <Arduino.h>
#include <math.h>

#include "FlightSupervisor.h"

#include "../board/BoardPins.h"
#include "../config/DronePetConfig.h"

#include "../control/AttitudeEstimator.h"
#include "../control/FlightController.h"

#include "../imu/ImuHealth.h"

#include "../tof/Tof.h"
#include "../tof/TofHealth.h"


namespace {

  FlightState currentState = FlightState::WaitingForReady;

  uint32_t stateStartedMs = 0;
  uint32_t landingNearGroundStartedMs = 0;
  bool landingNearGroundTimerRunning = false;

  void setLed(
      uint8_t red,
      uint8_t green,
      uint8_t blue
  ) {

    rgbLedWrite(
        STATUS_LED,
        red,
        green,
        blue
    );
  }

  bool tiltSafe(
      const AttitudeState& attitude
  ) {

    return fabsf(attitude.rollDeg)
            <= DronePetConfig::MAX_SAFE_TILT_DEG

        && fabsf(attitude.pitchDeg)
            <= DronePetConfig::MAX_SAFE_TILT_DEG;
  }


  bool sensorsReady(
      const AttitudeState& attitude,
      const ImuHealthStatus& imuHealth,
      const TofHealthStatus& tofHealth
  ) {

    return attitude.ready
        && imuHealth.healthy()
        && tofHealth.responsive()
        && tofHealth.rangeValid
        && tiltSafe(attitude);
  }


  void faultTilt() {
    FlightController::disarm();
    currentState = FlightState::Fault;

    // Red
    setLed(30, 0, 0);
  }

  void faultImu() {
    FlightController::disarm();
    currentState = FlightState::Fault;

    // Orange
    setLed(30, 10, 0);
  }

  void faultTof() {
    FlightController::disarm();
    currentState = FlightState::Fault;

    // Cyan
    setLed(0, 20, 20);
  }

  void faultController() {
    FlightController::disarm();
    currentState = FlightState::Fault;

    // Purple
    setLed(20, 0, 20);
  }


  void complete() {

    FlightController::disarm();

    currentState = FlightState::Complete;

    setLed(0, 30, 0);
  }

}


void FlightSupervisor::begin() {

  FlightController::begin();

  currentState = FlightState::WaitingForReady;

  stateStartedMs = millis();

  setLed(0, 0, 0);
}


void FlightSupervisor::update(
    const AttitudeState& attitude,
    const ImuHealthStatus& imuHealth,
    const TofSample& tofSample,
    const TofHealthStatus& tofHealth,
    float dtSeconds
) {

  const bool ready =
      sensorsReady(
          attitude,
          imuHealth,
          tofHealth
      );


  switch (currentState) {

    case FlightState::WaitingForReady:

      if (!ready) {
        return;
      }

      currentState =
          FlightState::ArmWarning;

      stateStartedMs = millis();

      // Yellow: motors will arm after warning period.
      setLed(30, 20, 0);

      return;


    case FlightState::ArmWarning:

      // If readiness disappears, restart the waiting process
      // rather than arming anyway.
      if (!ready) {

        currentState =
            FlightState::WaitingForReady;

        setLed(0, 0, 0);

        return;
      }


      if (
          millis() - stateStartedMs
          < DronePetConfig::ARM_WARNING_MS
      ) {
        return;
      }


      FlightController::arm();
      FlightController::setTargetAltitudeMm(
          DronePetConfig::HOVER_ALTITUDE_MM
      );
      currentState = FlightState::Flying;

      stateStartedMs = millis();

      // Blue: flight controller is actively driving motors.
      setLed(0, 0, 30);

      return;


    case FlightState::Flying:

      if (!imuHealth.healthy()) {
        faultImu();
        return;
      }

      if (!tofHealth.responsive()
          || !tofHealth.rangeValid) {

        faultTof();
        return;
      }

      if (!tiltSafe(attitude)) {
        faultTilt();
        return;
      }


      if (
          millis() - stateStartedMs
          >= DronePetConfig::FLIGHT_TEST_DURATION_MS
      ) {

        currentState = FlightState::Landing;

        stateStartedMs = millis();

        landingNearGroundTimerRunning = false;

        // Purple = controlled landing.
        setLed(20, 0, 20);

        return;
      }


      FlightController::update(
          attitude,
          imuHealth,
          tofSample,
          tofHealth,
          dtSeconds
      );

      // FlightController can also disarm itself if something
      // internally becomes invalid.
      if (!FlightController::armed()) {
        faultController();
        return;
      }

      return;

    case FlightState::Landing: {

      if (!ready
          || !tiltSafe(attitude)) {

        fault();

        return;
      }


      const uint32_t landingElapsedMs =
          millis() - stateStartedMs;


      // Smoothly ramp the commanded altitude downward.
      const float landingElapsedSeconds =
          static_cast<float>(landingElapsedMs)
          * 0.001f;


      float landingTargetMm =
          DronePetConfig::HOVER_ALTITUDE_MM
          - DronePetConfig::LANDING_RATE_MM_PER_S
              * landingElapsedSeconds;


      landingTargetMm =
          max(
              landingTargetMm,
              DronePetConfig::LANDING_TARGET_ALTITUDE_MM
          );


      FlightController::setTargetAltitudeMm(
          landingTargetMm
      );


      // Keep running the exact same real flight controller.
      FlightController::update(
          attitude,
          imuHealth,
          tofSample,
          tofHealth,
          dtSeconds
      );


      if (!FlightController::armed()) {

        fault();

        return;
      }


      // Detect that we're actually near the ground.
      if (
          tofSample.distanceMm
          <= DronePetConfig::LANDING_DISARM_HEIGHT_MM
      ) {

        if (!landingNearGroundTimerRunning) {

          landingNearGroundTimerRunning = true;

          landingNearGroundStartedMs = millis();
        }


        if (
            millis() - landingNearGroundStartedMs
            >= DronePetConfig::LANDING_CONFIRM_MS
        ) {

          complete();

          return;
        }

      }
      else {

        landingNearGroundTimerRunning = false;
      }


      // Backup safety cutoff.
      if (
          landingElapsedMs
          >= DronePetConfig::LANDING_TIMEOUT_MS
      ) {

        fault();

        return;
      }


      return;
    }

    case FlightState::Complete:
    case FlightState::Fault:

      // One-shot first-flight profile.
      // Requires a power cycle to fly again.
      return;
  }
}


FlightState FlightSupervisor::state() {
  return currentState;
}